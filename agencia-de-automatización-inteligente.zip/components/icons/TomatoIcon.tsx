import React from 'react';

interface TomatoIconProps {
  className?: string;
}

const TomatoIcon: React.FC<TomatoIconProps> = ({ className }) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" className={className || "w-6 h-6"}>
    <g clipPath="url(#clip0_tomato)">
      <path d="M24 10C16.268 10 10 16.268 10 24C10 31.732 16.268 38 24 38C31.732 38 38 31.732 38 24C38 16.268 31.732 10 24 10Z" fill="#FF6347"/>
      <path d="M24 10C24 9.44772 23.5523 9 23 9L20 9C19.4477 9 19 8.55228 19 8L19 6C19 5.44772 19.4477 5 20 5L22 5L23 3L25 5L27 5C27.5523 5 28 5.44772 28 6L28 8C28 8.55228 27.5523 9 27 9L25 9C24.4477 9 24 9.44772 24 10Z" fill="#32CD32"/>
      <ellipse cx="31" cy="19" rx="5" ry="3" fill="white" fillOpacity="0.6"/>
    </g>
    <defs>
      <clipPath id="clip0_tomato">
        <rect width="48" height="48" fill="white"/>
      </clipPath>
    </defs>
  </svg>
);

export default TomatoIcon;