
import React from 'react';

interface UserGroupIconProps {
  className?: string;
}

const UserGroupIcon: React.FC<UserGroupIconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-6 h-6"}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-3.741-5.013M13.5 18.72a9.094 9.094 0 013.741-.479 3 3 0 01-3.741-5.013M12 3c2.755 0 5.455.232 8.083.678 1.131.166 2.113.52 2.917.925v2.286c-.053.05-.107.1-.16.155A9.091 9.091 0 0118 18.72M12 3C9.245 3 6.545 3.232 3.917 3.678A2.969 2.969 0 001 6.652v2.286c.053.05.107.1.16.155A9.091 9.091 0 006 18.72m0-1.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm0 0a1.5 1.5 0 10-3 0 1.5 1.5 0 003 0z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 12.75a1.5 1.5 0 110-3 1.5 1.5 0 010 3z" />
  </svg>
);

export default UserGroupIcon;
