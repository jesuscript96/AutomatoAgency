
import React from 'react';

interface BriefcaseIconProps {
  className?: string;
}

const BriefcaseIcon: React.FC<BriefcaseIconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-6 h-6"}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 14.155V18a2.25 2.25 0 01-2.25 2.25h-12A2.25 2.25 0 013.75 18V9.75a2.25 2.25 0 012.25-2.25h12A2.25 2.25 0 0120.25 9.75v4.405M16.5 9.75V6.75A2.25 2.25 0 0014.25 4.5h-4.5A2.25 2.25 0 007.5 6.75v3M16.5 13.5L12 16.5m0 0L7.5 13.5m4.5 3V9" />
  </svg>
);

export default BriefcaseIcon;
