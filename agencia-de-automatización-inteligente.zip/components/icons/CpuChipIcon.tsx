
import React from 'react';

interface CpuChipIconProps {
  className?: string;
}

const CpuChipIcon: React.FC<CpuChipIconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-6 h-6"}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 3v1.5M4.5 8.25H3m18 0h-1.5M4.5 12H3m18 0h-1.5m-15 3.75H3m18 0h-1.5M8.25 19.5V21M12 3v1.5m0 15V21m3.75-18v1.5m0 15V21m-9.75-15h1.5a1.5 1.5 0 011.5 1.5v1.5h-1.5a1.5 1.5 0 01-1.5-1.5V3zM12 7.5h1.5a1.5 1.5 0 011.5 1.5v1.5h-1.5a1.5 1.5 0 01-1.5-1.5V7.5zM12 15h1.5a1.5 1.5 0 011.5 1.5v1.5h-1.5a1.5 1.5 0 01-1.5-1.5V15zM7.5 7.5h1.5a1.5 1.5 0 011.5 1.5v1.5h-1.5A1.5 1.5 0 017.5 9V7.5zM7.5 15h1.5a1.5 1.5 0 011.5 1.5v1.5h-1.5a1.5 1.5 0 01-1.5-1.5V15zM15 4.5v.01M15 19.5v.01M19.5 15v.01M4.5 15v.01M19.5 4.5v.01M15 12h-1.5a1.5 1.5 0 00-1.5 1.5v1.5h1.5a1.5 1.5 0 001.5-1.5V12zM7.5 4.5v.01M4.5 4.5v.01" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 9a2.25 2.25 0 100 4.5 2.25 2.25 0 000-4.5z" />
  </svg>
);

export default CpuChipIcon;
