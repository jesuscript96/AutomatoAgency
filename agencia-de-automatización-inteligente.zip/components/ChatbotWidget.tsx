import React, { useState } from 'react';
import { PRIMARY_COLOR } from '../constants';

const ChatbotWidget: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ sender: string; text: string }[]>([
    { sender: 'bot', text: '¡Hola! Soy su asistente virtual. ¿Cómo puedo ayudarle hoy?' }
  ]);
  const [inputText, setInputText] = useState('');

  const toggleChat = () => setIsOpen(!isOpen);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputText.trim() === '') return;
    setMessages([...messages, { sender: 'user', text: inputText }]);
    // Simulate bot response
    setTimeout(() => {
      setMessages(prev => [...prev, { sender: 'bot', text: 'Gracias por su mensaje. Un especialista se pondrá en contacto pronto.' }]);
    }, 1000);
    setInputText('');
  };

  return (
    <>
      <button
        onClick={toggleChat}
        className={`fixed bottom-6 right-6 bg-[${PRIMARY_COLOR}] text-white p-3 rounded-full shadow-lg hover:opacity-90 transition-opacity focus:outline-none focus:ring-2 focus:ring-[${PRIMARY_COLOR}] focus:ring-offset-2 z-50`}
        aria-label="Abrir chat de ayuda"
      >
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-7 h-7">
          <path strokeLinecap="round" strokeLinejoin="round" d="M8.625 12a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H8.25m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H12m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0h-.375M21 12c0 4.556-3.862 8.25-8.625 8.25S3.75 16.556 3.75 12C3.75 7.444 7.612 3.75 12.375 3.75S21 7.444 21 12z" />
        </svg>
      </button>

      {isOpen && (
        <div className="fixed bottom-24 right-6 w-80 sm:w-96 h-[500px] bg-white rounded-lg shadow-xl flex flex-col z-50 border border-[#dbe0e6]">
          <div className={`bg-[${PRIMARY_COLOR}] text-white p-3 rounded-t-lg flex justify-between items-center`}>
            <h3 className="font-semibold text-base">Asistente Virtual</h3>
            <button onClick={toggleChat} className="text-red-100 hover:text-white">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          <div className="flex-grow p-3 space-y-2 overflow-y-auto">
            {messages.map((msg, index) => (
              <div key={index} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[75%] p-2.5 rounded-lg text-sm ${msg.sender === 'user' ? `bg-[${PRIMARY_COLOR}] text-white` : 'bg-slate-100 text-[#111418]'}`}>
                  {msg.text}
                </div>
              </div>
            ))}
          </div>
          <form onSubmit={handleSendMessage} className="p-3 border-t border-[#dbe0e6]">
            <div className="flex space-x-2">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Escriba su mensaje..."
                className={`flex-grow px-3 py-2 border border-[#dbe0e6] rounded-md focus:outline-none focus:ring-1 focus:ring-[${PRIMARY_COLOR}] focus:border-[${PRIMARY_COLOR}] text-sm text-[#111418]`}
              />
              <button type="submit" className={`bg-[${PRIMARY_COLOR}] text-white px-4 py-2 rounded-md hover:opacity-90 transition-opacity text-sm font-semibold`}>
                Enviar
              </button>
            </div>
          </form>
        </div>
      )}
    </>
  );
};

export default ChatbotWidget;