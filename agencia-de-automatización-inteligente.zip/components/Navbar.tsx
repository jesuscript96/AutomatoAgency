import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { APP_NAME, NAVIGATION_LINKS, DEMO_CTA_TEXT, PRIMARY_COLOR } from '../constants';
import Button from './Button';
import TomatoIcon from './icons/TomatoIcon'; // Import new TomatoIcon

const Navbar: React.FC = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <header className="flex items-center justify-between whitespace-nowrap border-b border-solid border-gray-200 px-4 sm:px-10 py-3 sticky top-0 z-50 bg-white">
      <div className="flex items-center gap-2 sm:gap-4 text-gray-900">
        <Link to="/" className="flex items-center gap-2 text-current">
          <TomatoIcon className="size-6 sm:size-7" /> {/* Using TomatoIcon */}
          <h2 className="text-gray-900 text-base sm:text-lg font-bold leading-tight tracking-tight">{APP_NAME}</h2>
        </Link>
      </div>
      
      <nav className="hidden md:flex flex-1 justify-end items-center gap-4 sm:gap-8">
        <div className="flex items-center gap-3 sm:gap-6 lg:gap-9">
          {NAVIGATION_LINKS.map((link) => (
            <NavLink
              key={link.label}
              to={link.path}
              className={({ isActive }) =>
                `text-sm font-medium leading-normal transition-colors hover:text-[${PRIMARY_COLOR}] ${
                  isActive ? `text-[${PRIMARY_COLOR}]` : 'text-gray-900'
                }`
              }
            >
              {link.label}
            </NavLink>
          ))}
        </div>
        <Link to="/contacto?asunto=demo">
          <Button variant="primary" size="md">
            {DEMO_CTA_TEXT}
          </Button>
        </Link>
      </nav>

      <div className="flex md:hidden">
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          type="button"
          className="inline-flex items-center justify-center p-2 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-red-500"
          aria-controls="mobile-menu"
          aria-expanded={isMobileMenuOpen}
        >
          <span className="sr-only">Abrir menú principal</span>
          {isMobileMenuOpen ? (
            <svg className="block h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          ) : (
            <svg className="block h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          )}
        </button>
      </div>

      {isMobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-white shadow-lg z-40" id="mobile-menu">
          <nav className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {NAVIGATION_LINKS.map((link) => (
              <NavLink
                key={link.label}
                to={link.path}
                onClick={() => setIsMobileMenuOpen(false)}
                className={({ isActive }) =>
                  `block px-3 py-2 rounded-md text-base font-medium transition-colors ${
                    isActive
                      ? `bg-[${PRIMARY_COLOR}] text-white`
                      : `text-gray-900 hover:bg-gray-100 hover:text-[${PRIMARY_COLOR}]`
                  }`
                }
              >
                {link.label}
              </NavLink>
            ))}
            <Link to="/contacto?asunto=demo" className="block w-full text-left mt-2" onClick={() => setIsMobileMenuOpen(false)}>
                <Button variant="primary" size="md" className="w-full">
                    {DEMO_CTA_TEXT}
                </Button>
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Navbar;