import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import Button from './Button';
import { PRIMARY_COLOR, DEMO_CTA_TEXT as CONTACT_BUTTON_TEXT } from '../constants';
import emailjs from '@emailjs/browser';

interface FormData {
  nombre: string;
  email: string;
  empresa: string;
  asunto: string;
  mensaje: string;
}

// User-provided EmailJS IDs
const EMAILJS_SERVICE_ID = 'service_fi3alud';
const EMAILJS_TEMPLATE_ID = 'template_aw41htv';
const EMAILJS_PUBLIC_KEY = 'AoJ-f1IqBNcxuSfvk';
// Asegúrate de que tu plantilla de EmailJS esté configurada para usar estas variables:
// nombre, email, empresa, asunto, mensaje

const ContactForm: React.FC = () => {
  const location = useLocation();
  const [formData, setFormData] = useState<FormData>({
    nombre: '',
    email: '',
    empresa: '',
    asunto: '',
    mensaje: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const queryParams = new URLSearchParams(location.search);
    const asuntoParam = queryParams.get('asunto');
    if (asuntoParam) {
      const asuntosMap: { [key: string]: string } = {
        'demo': `Solicitud de ${CONTACT_BUTTON_TEXT}`,
        'consulta': 'Solicitud de Consulta Personalizada',
        'colaboracion': 'Propuesta de Colaboración o Carrera',
        'pregunta_adicional': 'Pregunta Adicional sobre Servicios'
      };
      setFormData(prev => ({ ...prev, asunto: asuntosMap[asuntoParam] || asuntoParam }));
    }
  }, [location.search]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prevData => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);
    setIsSubmitted(false);


    if (!formData.nombre || !formData.email || !formData.asunto || !formData.mensaje) {
      setError("Por favor, complete todos los campos obligatorios.");
      setIsSubmitting(false);
      return;
    }

    // Since actual EmailJS IDs are provided, the placeholder check is removed.
    // The form will directly attempt to send using the configured IDs.
    
    const templateParams = {
        nombre: formData.nombre,
        email: formData.email,
        empresa: formData.empresa,
        asunto: formData.asunto,
        mensaje: formData.mensaje,
        // Puedes añadir más parámetros aquí si los necesitas en tu plantilla de EmailJS
        // Por ejemplo: to_email: 'jvalenzuela.chulia@gmail.com' (si tu plantilla lo soporta)
    };

    try {
      await emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, templateParams, EMAILJS_PUBLIC_KEY);
      setIsSubmitted(true);
      setFormData({ nombre: '', email: '', empresa: '', asunto: '', mensaje: '' }); 
      setTimeout(() => setIsSubmitted(false), 5000); // Resetear mensaje de éxito después de 5s
    } catch (err: any) {
      console.error("Error al enviar con EmailJS:", err);
      setError(err.text || "Error al enviar el mensaje. Intente de nuevo más tarde.");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSubmitted && !error) {
    return (
      <div className="bg-green-50 border border-green-300 text-green-700 p-4 rounded-lg shadow-md" role="alert">
        <h3 className="font-bold text-base text-green-800 mb-1">¡Gracias por su mensaje!</h3>
        <p className="text-sm">Hemos recibido su solicitud y nos pondremos en contacto con usted a la brevedad.</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-lg border border-[#dbe0e6]">
      {error && <div className="bg-red-50 border border-red-300 text-red-700 px-4 py-2 rounded-md text-sm" role="alert">{error}</div>}
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="nombre" className="block text-xs font-medium text-[#60748a] mb-1">Nombre Completo *</label>
          <input type="text" name="nombre" id="nombre" value={formData.nombre} onChange={handleChange} required className={`mt-1 block w-full px-3 py-2 border border-[#dbe0e6] rounded-md shadow-sm focus:outline-none focus:ring-[${PRIMARY_COLOR}] focus:border-[${PRIMARY_COLOR}] sm:text-sm text-[#111418]`} placeholder="Ej: Ana Pérez" />
        </div>
        <div>
          <label htmlFor="email" className="block text-xs font-medium text-[#60748a] mb-1">Correo Electrónico *</label>
          <input type="email" name="email" id="email" value={formData.email} onChange={handleChange} required className={`mt-1 block w-full px-3 py-2 border border-[#dbe0e6] rounded-md shadow-sm focus:outline-none focus:ring-[${PRIMARY_COLOR}] focus:border-[${PRIMARY_COLOR}] sm:text-sm text-[#111418]`} placeholder="Ej: ana.perez@empresa.com" />
        </div>
      </div>
      <div>
        <label htmlFor="empresa" className="block text-xs font-medium text-[#60748a] mb-1">Empresa (Opcional)</label>
        <input type="text" name="empresa" id="empresa" value={formData.empresa} onChange={handleChange} className={`mt-1 block w-full px-3 py-2 border border-[#dbe0e6] rounded-md shadow-sm focus:outline-none focus:ring-[${PRIMARY_COLOR}] focus:border-[${PRIMARY_COLOR}] sm:text-sm text-[#111418]`} placeholder="Ej: Acme Corp" />
      </div>
      <div>
        <label htmlFor="asunto" className="block text-xs font-medium text-[#60748a] mb-1">Asunto *</label>
        <input type="text" name="asunto" id="asunto" value={formData.asunto} onChange={handleChange} required className={`mt-1 block w-full px-3 py-2 border border-[#dbe0e6] rounded-md shadow-sm focus:outline-none focus:ring-[${PRIMARY_COLOR}] focus:border-[${PRIMARY_COLOR}] sm:text-sm text-[#111418]`} placeholder="Ej: Solicitud de información"/>
      </div>
      <div>
        <label htmlFor="mensaje" className="block text-xs font-medium text-[#60748a] mb-1">Mensaje *</label>
        <textarea name="mensaje" id="mensaje" rows={4} value={formData.mensaje} onChange={handleChange} required className={`mt-1 block w-full px-3 py-2 border border-[#dbe0e6] rounded-md shadow-sm focus:outline-none focus:ring-[${PRIMARY_COLOR}] focus:border-[${PRIMARY_COLOR}] sm:text-sm text-[#111418]`} placeholder="Escriba su mensaje aquí..."></textarea>
      </div>
      <div>
        <Button type="submit" variant="primary" size="md" className="w-full sm:w-auto" disabled={isSubmitting}>
          {isSubmitting ? 'Enviando...' : 'Enviar Mensaje'}
        </Button>
      </div>
      <div className="text-xs text-[#60748a] mt-2">
        <p>Este formulario utiliza EmailJS para el envío de correos.</p>
      </div>
    </form>
  );
};

export default ContactForm;