import React from 'react';
import { PLACEHOLDER_IMAGE_URL } from '../../constants';
import ShieldCheckIcon from '../icons/ShieldCheckIcon'; // Using the existing one

const CybersecuritySectionContent: React.FC = () => {
  const securityMeasures = [
    "Encriptación avanzada de datos en reposo y en tránsito.",
    "Controles de acceso granulares y autenticación multifactor (MFA).",
    "Pistas de auditoría detalladas para trazabilidad y responsabilidad.",
    "Monitorización continua y detección de amenazas en tiempo real.",
    "Planes de respuesta a incidentes y recuperación ante desastres."
  ];

  return (
    <div className="space-y-8 text-[#111418]">
      <div className="md:flex md:items-center md:space-x-6">
        <div className="md:w-1/3 mb-4 md:mb-0">
            <img src={PLACEHOLDER_IMAGE_URL(400,350, 'cybersecurity-shield')} alt="Ciberseguridad" className="rounded-md w-full h-auto object-cover" />
        </div>
        <div className="md:w-2/3">
            <p className="text-base leading-normal text-[#60748a] mb-3">
                En la era digital, la protección de la información sensible y el cumplimiento de las regulaciones son fundamentales. A medida que las empresas adoptan la automatización y la digitalización, la superficie de ataque potencial puede expandirse. Nuestras soluciones de ciberseguridad están diseñadas para proteger sus activos digitales, asegurar la continuidad del negocio y mantener la confianza de sus clientes.
            </p>
            <p className="text-base leading-normal text-[#60748a]">
                Abordamos la seguridad desde una perspectiva integral, considerando tanto las amenazas externas como los riesgos internos, y ayudamos a cumplir con normativas como el RGPD (Reglamento General de Protección de Datos) o la obligatoriedad del registro digital de jornada laboral en España (a partir de 2025).
            </p>
        </div>
      </div>
      
      <div>
        <h3 className="text-lg font-bold leading-tight text-[#111418] mb-3">Nuestras Medidas de Seguridad</h3>
        <ul className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-3">
          {securityMeasures.map((measure, index) => (
            <li key={index} className="flex items-start">
              <ShieldCheckIcon className="w-5 h-5 text-green-600 mr-2 flex-shrink-0 mt-1" />
              <span className="text-sm text-[#60748a]">{measure}</span>
            </li>
          ))}
        </ul>
      </div>

      <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
        <h3 className="text-lg font-bold leading-tight text-red-700 mb-2">IA Responsable y Ética</h3>
        <p className="text-sm text-[#60748a] leading-normal mb-2">
          La adopción de la Inteligencia Artificial conlleva responsabilidades éticas. Nos comprometemos a desarrollar e implementar soluciones de IA que sean:
        </p>
        <ul className="list-disc list-inside space-y-1 text-sm text-[#60748a]">
          <li><span className="font-medium text-red-600">Transparentes:</span> Comprensibles en su funcionamiento y toma de decisiones.</li>
          <li><span className="font-medium text-red-600">Equitativas:</span> Con detección y mitigación activa de sesgos para evitar discriminaciones.</li>
          <li><span className="font-medium text-red-600">Privadas:</span> Con una robusta protección de la privacidad de los datos utilizados y generados.</li>
          <li><span className="font-medium text-red-600">Seguras:</span> Protegidas contra manipulaciones y usos indebidos.</li>
        </ul>
        <p className="text-sm text-[#60748a] leading-normal mt-2">
          Fomentamos un enfoque ético en cada proyecto de IA, asegurando que la tecnología se utilice para el bien común y el progreso responsable.
        </p>
      </div>
    </div>
  );
};

export default CybersecuritySectionContent;