import React from 'react';
import { PLACEHOLDER_IMAGE_URL, PRIMARY_COLOR } from '../../constants';

const RpaSectionContent: React.FC = () => {
  const useCases = {
    hr: {
      title: "Recursos Humanos",
      items: [
        "Incorporación (Onboarding): Reducción del proceso de 5 días a 24 horas.",
        "Reclutamiento: IA generativa para selección de CV, hasta un 75% menos de tiempo de selección.",
        "Gestión de consultas internas: Chatbots corporativos, ahorro de 2h/semana por empleado."
      ],
      imageUrl: PLACEHOLDER_IMAGE_URL(400, 250, 'rpa-hr')
    },
    logistics: {
      title: "Logística",
      items: [
        "Robots en almacén: Mayor velocidad, menor costo laboral y precisión en envíos (ej. Inditex, Amazon).",
        "Trazabilidad en tiempo real con IoT (Internet de las Cosas)."
      ],
      imageUrl: PLACEHOLDER_IMAGE_URL(400, 250, 'rpa-logistics')
    },
    marketing: {
      title: "Marketing",
      items: [
        "Orquestación de campañas y nutrición de leads (lead nurturing).",
        "Ahorro anual promedio de $300,000 USD."
      ],
      imageUrl: PLACEHOLDER_IMAGE_URL(400, 250, 'rpa-marketing')
    },
    finance: {
      title: "Finanzas",
      items: [
        "Gestión de facturas, conciliaciones bancarias.",
        "Generación automatizada de informes financieros."
      ],
      imageUrl: PLACEHOLDER_IMAGE_URL(400, 250, 'rpa-finance')
    }
  };

  return (
    <div className="space-y-8 text-[#111418]">
      <p className="text-base leading-normal text-[#60748a]">
        La Automatización Robótica de Procesos (RPA) utiliza tecnología para ejecutar tareas repetitivas y basadas en reglas sin intervención humana constante. Es aplicable tanto a sistemas internos (back-office) como a servicios orientados al cliente (front-office), liberando a su equipo para que se concentre en actividades de mayor valor estratégico.
      </p>
      
      <div>
        <h3 className="text-lg font-bold leading-tight text-[#111418] mb-3">Beneficios Clave del RPA</h3>
        <ul className={`list-disc list-inside space-y-2 text-[#60748a] bg-red-50 p-4 rounded-md border border-red-200`}>
          <li><span className="font-medium text-[#111418]">Ahorro de Tiempo Significativo:</span> Automatiza procesos manuales y reduce drásticamente los tiempos de ejecución.</li>
          <li><span className="font-medium text-[#111418]">Reducción de Errores:</span> Minimiza errores humanos, mejorando la precisión y calidad de los datos.</li>
          <li><span className="font-medium text-[#111418]">Optimización de Recursos:</span> Libera al personal para tareas de mayor valor añadido y creatividad.</li>
          <li><span className="font-medium text-[#111418]">Ventaja Competitiva:</span> Aumenta la eficiencia operativa y la capacidad de respuesta al mercado.</li>
          <li><span className="font-medium text-[#111418]">Escalabilidad y Flexibilidad:</span> Adapta fácilmente la capacidad de sus procesos a las demandas cambiantes.</li>
        </ul>
      </div>

      <div>
        <h3 className="text-lg font-bold leading-tight text-[#111418] mb-4">Casos de Uso por Área</h3>
        <div className="space-y-6">
          {Object.entries(useCases).map(([key, uc]) => (
            <div key={key} className="p-4 border border-[#dbe0e6] rounded-lg bg-white">
              <div className="md:flex md:items-start md:space-x-4">
                <img src={uc.imageUrl} alt={uc.title} className="w-full md:w-1/3 h-auto object-cover rounded-md mb-3 md:mb-0" />
                <div className="md:w-2/3">
                  <h4 className={`text-base font-bold text-[${PRIMARY_COLOR}] mb-2`}>{uc.title}</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-[#60748a]">
                    {uc.items.map((item, index) => (
                      <li key={index}>{item}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default RpaSectionContent;