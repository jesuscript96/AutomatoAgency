import React from 'react';
import { PLACEHOLDER_IMAGE_URL } from '../../constants';

const LowCodeSectionContent: React.FC = () => {
  return (
    <div className="space-y-8 text-[#111418]">
      <div className="md:flex md:items-center md:space-x-6">
        <div className="md:w-2/3">
          <p className="text-base leading-normal text-[#60748a] mb-4">
            Las plataformas Low-Code/No-Code están revolucionando la forma en que se desarrollan aplicaciones y se automatizan procesos. Estas herramientas democratizan el desarrollo de software, permitiendo a usuarios con poca o ninguna experiencia en programación (conocidos como "citizen developers" o desarrolladores ciudadanos) crear, modificar e implementar soluciones empresariales de manera rápida y eficiente.
          </p>
          <p className="text-base leading-normal text-[#60748a]">
            Al utilizar interfaces visuales intuitivas, constructores de arrastrar y soltar, y modelos preconstruidos, las empresas pueden acelerar drásticamente sus ciclos de innovación y adaptarse con agilidad a los cambios constantes del mercado.
          </p>
        </div>
        <div className="md:w-1/3 mt-4 md:mt-0">
            <img src={PLACEHOLDER_IMAGE_URL(400,300, 'lowcode-platform')} alt="Plataforma Low-Code" className="rounded-md w-full h-auto object-cover" />
        </div>
      </div>

      <div>
        <h3 className="text-lg font-bold leading-tight text-[#111418] mb-3">Beneficios Clave de Low-Code/No-Code</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-green-50 p-4 rounded-md border border-green-200">
            <h4 className="text-base font-bold text-green-700 mb-1">Mayor Agilidad y Velocidad</h4>
            <p className="text-sm text-[#60748a]">Implemente nuevos procesos, servicios o aplicaciones en una fracción del tiempo que tomaría el desarrollo tradicional.</p>
          </div>
          <div className="bg-green-50 p-4 rounded-md border border-green-200">
            <h4 className="text-base font-bold text-green-700 mb-1">Reducción de Costos</h4>
            <p className="text-sm text-[#60748a]">Disminuya la dependencia de desarrolladores especializados y reduzca los costos asociados al desarrollo y mantenimiento de software.</p>
          </div>
          <div className="bg-green-50 p-4 rounded-md border border-green-200">
            <h4 className="text-base font-bold text-green-700 mb-1">Empoderamiento de Equipos</h4>
            <p className="text-sm text-[#60748a]">Permita a los expertos de negocio y otros usuarios no técnicos participar activamente en la creación de soluciones que satisfagan sus necesidades específicas.</p>
          </div>
          <div className="bg-green-50 p-4 rounded-md border border-green-200">
            <h4 className="text-base font-bold text-green-700 mb-1">Innovación Acelerada</h4>
            <p className="text-sm text-[#60748a]">Facilite la experimentación y el prototipado rápido, fomentando una cultura de innovación continua dentro de la organización.</p>
          </div>
        </div>
      </div>
      <p className="text-base leading-normal text-[#60748a] mt-4">
        Le ayudamos a identificar las mejores plataformas Low-Code/No-Code para sus necesidades y a capacitar a sus equipos para que aprovechen al máximo su potencial, transformando ideas en soluciones funcionales en tiempo récord.
      </p>
    </div>
  );
};

export default LowCodeSectionContent;