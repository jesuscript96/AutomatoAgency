import React from 'react';
import { PLACEHOLDER_IMAGE_URL, PRIMARY_COLOR } from '../../constants';

const AiMlSectionContent: React.FC = () => {
  const aiTypes = [
    { 
      title: "IA Generativa", 
      description: "Creación automática de contenidos (textos, imágenes, código), diseño asistido, chatbots avanzados y copilotos inteligentes para potenciar la productividad.",
      imageUrl: PLACEHOLDER_IMAGE_URL(300, 200, 'ai-generative') 
    },
    { 
      title: "Minería de Procesos (Process Mining)", 
      description: "Descubrimiento, análisis y mejora de procesos de negocio reales basados en datos de eventos para identificar cuellos de botella e ineficiencias.",
      imageUrl: PLACEHOLDER_IMAGE_URL(300, 200, 'ai-process-mining') 
    },
    { 
      title: "Big Data y Analítica Avanzada", 
      description: "Análisis de grandes volúmenes de datos para planificación predictiva, pronóstico de demanda, segmentación de clientes y optimización de estrategias.",
      imageUrl: PLACEHOLDER_IMAGE_URL(300, 200, 'ai-bigdata') 
    },
  ];

  return (
    <div className="space-y-8 text-[#111418]">
      <p className="text-base leading-normal text-[#60748a]">
        La Inteligencia Artificial (IA) y el Aprendizaje Automático (Machine Learning - ML) enriquecen la funcionalidad de los sistemas automatizados, permitiéndoles comprender, aprender y adaptarse. Esto se traduce en una toma de decisiones más inteligente, automatización de contenido sofisticada y análisis avanzado de datos. La IA permite analizar grandes volúmenes de información de manera rápida y precisa, fundamental para decisiones informadas y estratégicas.
      </p>

      <div>
        <h3 className="text-lg font-bold leading-tight text-[#111418] mb-4">Tipos de IA y Aplicaciones</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {aiTypes.map(type => (
            <div key={type.title} className="p-4 border border-[#dbe0e6] rounded-lg bg-white flex flex-col">
              <img src={type.imageUrl} alt={type.title} className="w-full h-32 object-cover rounded-md mb-3"/>
              <h4 className={`text-base font-bold text-[${PRIMARY_COLOR}] mb-2`}>{type.title}</h4>
              <p className="text-sm text-[#60748a] flex-grow">{type.description}</p>
            </div>
          ))}
        </div>
      </div>
      
      <div className={`p-4 bg-red-50 border border-red-200 rounded-lg`}>
        <h3 className={`text-lg font-bold leading-tight text-red-700 mb-2`}>IA Personificada: Conexiones Emocionales</h3>
        <p className="text-sm text-[#60748a] leading-normal">
          Vamos más allá de la funcionalidad. Desarrollamos soluciones de IA que pueden reflejar la personalidad de su marca, creando conexiones emocionales más profundas con sus clientes. Esto no solo mejora la experiencia del usuario, sino que también diferencia a su empresa en un mercado competitivo, fomentando la lealtad y el compromiso.
        </p>
      </div>

      <div className="p-4 border border-[#dbe0e6] rounded-lg bg-white">
        <h3 className="text-lg font-bold leading-tight text-[#111418] mb-3">Chatbots y Asistentes Virtuales Inteligentes</h3>
        <div className="md:flex md:items-center md:space-x-4">
            <img src={PLACEHOLDER_IMAGE_URL(300,300, 'chatbot-ai')} alt="Chatbot Inteligente" className="w-full md:w-1/3 h-auto object-cover rounded-md mb-3 md:mb-0"/>
            <div className="md:w-2/3">
                <p className="text-sm text-[#60748a] leading-normal mb-2">
                    Implementamos chatbots y asistentes virtuales avanzados que ofrecen interacciones personalizadas, fluidas y omnicanal, disponibles 24/7. Estos no son simples contestadores automáticos; utilizan IA para comprender la intención del usuario, resolver consultas complejas, guiar a los clientes y realizar tareas, mejorando la satisfacción y eficiencia.
                </p>
                <ul className="list-disc list-inside space-y-1 text-sm text-[#60748a]">
                    <li>Atención al cliente 24/7.</li>
                    <li>Respuestas instantáneas y personalizadas.</li>
                    <li>Reducción de costos operativos de soporte.</li>
                    <li>Calificación y enrutamiento de prospectos (leads).</li>
                    <li>Integración con sistemas CRM y ERP.</li>
                </ul>
            </div>
        </div>
      </div>
    </div>
  );
};

export default AiMlSectionContent;