import React from 'react';
import { PRIMARY_COLOR } from '../constants';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'custom';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  children: React.ReactNode;
  customClassName?: string;
}

const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  className = '',
  customClassName, // Allow full override for very specific cases
  ...props
}) => {
  if (customClassName) {
    return (
      <button className={customClassName} {...props}>
        <span className="truncate">{children}</span>
      </button>
    );
  }
  
  const baseStyles = 'flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg transition-opacity duration-200 ease-in-out hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2';
  
  let variantStyles = '';
  switch (variant) {
    case 'primary':
      variantStyles = `bg-[${PRIMARY_COLOR}] text-white focus:ring-[${PRIMARY_COLOR}]`;
      break;
    case 'secondary': 
      variantStyles = `bg-red-700 hover:bg-red-800 text-white focus:ring-red-600`; // Darker red variant
      break;
    case 'outline':
      variantStyles = `bg-transparent border border-[${PRIMARY_COLOR}] text-[${PRIMARY_COLOR}] hover:bg-red-50 focus:ring-[${PRIMARY_COLOR}]`;
      break;
  }

  let sizeStyles = '';
  switch (size) {
    case 'sm':
      sizeStyles = 'h-8 px-3 text-xs font-bold leading-normal tracking-tight';
      break;
    case 'md': 
      sizeStyles = 'h-10 px-4 text-sm font-bold leading-normal tracking-tight';
      break;
    case 'lg': 
      sizeStyles = 'h-12 px-5 text-base font-bold leading-normal tracking-tight';
      break;
    case 'xl': 
      sizeStyles = 'h-14 px-6 text-lg font-bold leading-normal tracking-tight';
      break;
  }

  return (
    <button
      className={`${baseStyles} ${variantStyles} ${sizeStyles} ${className}`}
      {...props}
    >
      <span className="truncate">{children}</span>
    </button>
  );
};

export default Button;