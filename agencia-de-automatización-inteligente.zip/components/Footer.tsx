import React from 'react';
import { APP_NAME, FOOTER_LINKS } from '../constants';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="flex justify-center bg-white border-t border-gray-200">
      <div className="flex max-w-[960px] flex-1 flex-col">
        <div className="flex flex-col gap-6 px-5 py-10 text-center">
          <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-3">
            {FOOTER_LINKS.map(link => (
              <Link key={link.label} to={link.path} className="text-gray-600 text-base font-normal leading-normal min-w-40 hover:text-gray-900 transition-colors">
                {link.label}
              </Link>
            ))}
             {/* Add contact info if needed, or other links like in the original footer */}
          </div>
          <p className="text-gray-600 text-base font-normal leading-normal">
            © {new Date().getFullYear()} {APP_NAME}. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;