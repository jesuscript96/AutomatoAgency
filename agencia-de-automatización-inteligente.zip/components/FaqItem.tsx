import React, { useState } from 'react';
import { PRIMARY_COLOR } from '../constants';

interface FaqItemProps {
  question: string;
  answer: string;
}

const FaqItem: React.FC<FaqItemProps> = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border border-[#dbe0e6] rounded-lg bg-white overflow-hidden">
      <dt>
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="flex w-full items-center justify-between text-left text-[#111418] p-4 hover:bg-slate-50 focus:outline-none"
          aria-expanded={isOpen}
          aria-controls={`faq-answer-${question.replace(/\s+/g, '-')}`}
        >
          <span className="text-base font-bold leading-tight">{question}</span>
          <span className="ml-6 flex h-7 items-center">
            {isOpen ? (
              <svg className={`h-5 w-5 transform rotate-180 text-[${PRIMARY_COLOR}]`} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
              </svg>
            ) : (
              <svg className="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
              </svg>
            )}
          </span>
        </button>
      </dt>
      {isOpen && (
        <dd className="p-4 border-t border-[#dbe0e6]" id={`faq-answer-${question.replace(/\s+/g, '-')}`}>
          <p className="text-sm text-[#60748a] leading-normal">{answer}</p>
        </dd>
      )}
    </div>
  );
};

export default FaqItem;