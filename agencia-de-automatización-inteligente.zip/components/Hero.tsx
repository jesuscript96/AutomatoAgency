import React from 'react';
import Button from './Button';
import { DEMO_CTA_TEXT } from '../constants';
import { Link } from 'react-router-dom';

interface HeroProps {
  title: string;
  subtitle: string;
  imageUrl?: string;
}

const DEFAULT_HERO_IMAGE = "https://lh3.googleusercontent.com/aida-public/AB6AXuDIkWk85pslbeimlFH11uFLRaKDnWWZ5C3Q89f2TPd-0nzZg_SwW3nROJNjkWj--D4h7lerCOu7Tg8BnvpQMERWevg-ty2ycOcQUH7mj8MJfaSjxj4pgfuAYJ97eYKk4-F_b1odEHIHt3TVi7PK83b9kremoYYU1vWkb7TknLmE4XLMN0XLuvKzNy2PdSfW0rKmfSx7I_BPXpzbZ6V50M-6iLHUQwMBFPQ-hUr38hzv8boF3mx1zyJnUF7uzO3K9iAh4H5dK4ddypE";


const Hero: React.FC<HeroProps> = ({ 
  title, 
  subtitle, 
  imageUrl = DEFAULT_HERO_IMAGE, 
}) => {
  return (
    <div className="sm:p-1 md:p-2 lg:p-4">
      <div
        className="flex min-h-[480px] flex-col gap-6 bg-cover bg-center bg-no-repeat sm:gap-8 sm:rounded-lg items-start justify-end px-4 pb-10 sm:px-10"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.1) 0%, rgba(0, 0, 0, 0.4) 100%), url("${imageUrl}")`,
        }}
      >
        <div className="flex flex-col gap-2 text-left">
          <h1 className="text-white text-4xl font-black leading-tight tracking-tighter sm:text-5xl">
            {title}
          </h1>
          <h2 className="text-white text-sm font-normal leading-normal sm:text-base max-w-2xl">
            {subtitle}
          </h2>
        </div>
        <Link to="/contacto?asunto=demo">
          <Button variant="primary" size="lg">
            {DEMO_CTA_TEXT}
          </Button>
        </Link>
      </div>
    </div>
  );
};

export default Hero;