import React, { useEffect, useState, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import RpaSectionContent from '../components/services/RpaSectionContent';
import AiMlSectionContent from '../components/services/AiMlSectionContent';
import LowCodeSectionContent from '../components/services/LowCodeSectionContent';
import CybersecuritySectionContent from '../components/services/CybersecuritySectionContent';

import ArrowPathIcon from '../components/icons/ArrowPathIcon';
import CpuChipIcon from '../components/icons/CpuChipIcon';
import CodeBracketSquareIcon from '../components/icons/CodeBracketSquareIcon';
import ShieldCheckIcon from '../components/icons/ShieldCheckIcon';
import { PRIMARY_COLOR } from '../constants';

interface ServiceInfo {
  id: string;
  title: string;
  Icon: React.FC<{className?: string}>;
  ContentComponent: React.FC;
  description: string;
  shortTitle: string;
}

const servicesData: ServiceInfo[] = [
  { 
    id: 'rpa', 
    title: 'Automatización Robótica de Procesos (RPA)', 
    shortTitle: 'RPA',
    Icon: ArrowPathIcon, 
    ContentComponent: RpaSectionContent,
    description: 'Utilice robots de software para automatizar tareas manuales repetitivas, liberando a su equipo para iniciativas estratégicas.'
  },
  { 
    id: 'ia-ml', 
    title: 'Inteligencia Artificial (IA) y Machine Learning (ML)', 
    shortTitle: 'IA y ML',
    Icon: CpuChipIcon, 
    ContentComponent: AiMlSectionContent,
    description: 'Implemente soluciones de IA para análisis predictivo, personalización, toma de decisiones inteligente y más.'
  },
  { 
    id: 'low-code', 
    title: 'Plataformas Low-Code/No-Code', 
    shortTitle: 'Low-Code',
    Icon: CodeBracketSquareIcon, 
    ContentComponent: LowCodeSectionContent,
    description: 'Desarrolle e implemente aplicaciones rápidamente con una codificación mínima, empoderando a los desarrolladores ciudadanos.'
  },
  { 
    id: 'ciberseguridad', 
    title: 'Ciberseguridad y Cumplimiento Normativo', 
    shortTitle: 'Ciberseguridad',
    Icon: ShieldCheckIcon, 
    ContentComponent: CybersecuritySectionContent,
    description: 'Proteja sus activos digitales y asegure el cumplimiento normativo con nuestras soluciones integrales de ciberseguridad.'
  },
];

const ServicesPage: React.FC = () => {
  const location = useLocation();
  const [activeSection, setActiveSection] = useState<string | null>(servicesData[0]?.id || null); // Default to first section
  const sectionRefs = useRef<Record<string, HTMLElement | null>>({});
  const subNavRef = useRef<HTMLElement | null>(null);

  const getNavbarOffset = () => {
    const mainNavHeight = document.querySelector('header')?.offsetHeight || 0;
    const subNavElement = subNavRef.current;
    const subNavHeight = subNavElement?.offsetHeight || 0;
    return mainNavHeight + subNavHeight + 20; // 20px extra padding
  };

  const scrollToSection = (sectionId: string, behavior: ScrollBehavior = 'smooth') => {
    const element = document.getElementById(sectionId);
    if (element) {
      const offset = getNavbarOffset();
      const elementPosition = element.getBoundingClientRect().top + window.scrollY;
      const targetPosition = elementPosition - offset;

      window.scrollTo({
        top: targetPosition,
        behavior: behavior
      });
      if (history.pushState) { // Check if history.pushState is available
        history.pushState(null, '', `#${sectionId}`);
      }
      setActiveSection(sectionId);
    }
  };
  
  useEffect(() => {
    if (location.hash) {
      const id = location.hash.replace('#', '');
      // Use a timeout to ensure elements are rendered and heights are calculable
      setTimeout(() => scrollToSection(id, 'auto'), 100); 
    } else if (servicesData.length > 0) {
       // If no hash, ensure the view is at the top or scrolled to the first section if desired
       // For now, let's keep it simple and rely on ScrollToTop component for general top scroll
       // setActiveSection(servicesData[0].id); // Optionally set first section as active
    }

    const observerCallback = (entries: IntersectionObserverEntry[]) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
           // Only update activeSection if not manually set by click recently
           // to avoid jitter during scroll if multiple sections are in view
           if (entry.intersectionRatio > 0.5) { // Prioritize section more in view
             setActiveSection(entry.target.id);
           }
        }
      });
    };

    const mainNavHeight = document.querySelector('header')?.offsetHeight || 0;
    const subNavElement = subNavRef.current;
    const subNavHeight = subNavElement?.offsetHeight || 0;
    // Adjust rootMargin: top margin is negative sum of nav heights + a bit more to trigger when section top is well below navs
    // Bottom margin can be adjusted to change when the "next" section becomes active as you scroll down
    const topMargin = -(mainNavHeight + subNavHeight + 20); // e.g., if total height is 120, topMargin is -140px
    
    const observerOptions = {
      root: null, 
      rootMargin: `${topMargin}px 0px -40% 0px`, // Trigger when top of section is under navs, and consider 60% of section out of view from bottom
      threshold: [0.1, 0.5, 0.9] // Multiple thresholds can help decide "most visible"
    };

    const observer = new IntersectionObserver(observerCallback, observerOptions);
    Object.values(sectionRefs.current).forEach(section => {
      if (section) observer.observe(section);
    });

    return () => {
      Object.values(sectionRefs.current).forEach(section => {
        if (section) observer.unobserve(section);
      });
    };
  }, [location.hash]); // Only re-run if hash changes for initial load
  
  const handleSubNavClick = (e: React.MouseEvent<HTMLAnchorElement>, sectionId: string) => {
    e.preventDefault();
    scrollToSection(sectionId);
  };


  return (
    <div className="flex flex-col w-full">
      <div className={`bg-[${PRIMARY_COLOR}] text-white px-4 py-10 sm:px-10 sm:py-16 text-center`}>
        <h1 className="text-3xl sm:text-4xl font-black leading-tight tracking-tighter">Nuestros Servicios de Transformación Digital</h1>
        <p className="mt-3 text-base sm:text-lg text-red-100 max-w-3xl mx-auto">
          Descubra cómo nuestras soluciones de automatización y digitalización pueden impulsar su negocio hacia el futuro.
        </p>
      </div>

      <nav 
        id="services-subnav" 
        ref={el => { if (el) subNavRef.current = el; }} 
        className="sticky top-[65px] md:top-[69px] z-40 bg-white border-b border-gray-200 shadow-sm"
      >
        <div className="max-w-[960px] mx-auto px-4 sm:px-0">
          <div className="flex justify-center sm:justify-start space-x-2 sm:space-x-4 overflow-x-auto py-2">
            {servicesData.map(service => (
              <a
                key={service.id}
                href={`#${service.id}`}
                onClick={(e) => handleSubNavClick(e, service.id)}
                className={`px-3 py-1.5 text-xs sm:text-sm font-medium rounded-md whitespace-nowrap transition-colors duration-150
                  ${activeSection === service.id 
                    ? `bg-[${PRIMARY_COLOR}] text-white shadow-sm` 
                    : `text-gray-600 hover:text-[${PRIMARY_COLOR}] hover:bg-red-50`
                  }`}
              >
                {service.shortTitle}
              </a>
            ))}
          </div>
        </div>
      </nav>

      <div className="py-5">
        {servicesData.map(({ id, title, Icon, ContentComponent, description }) => (
          <section 
            key={id} 
            id={id} 
            ref={el => { sectionRefs.current[id] = el; }}
            className="py-5 scroll-mt-[130px] md:scroll-mt-[140px]" 
          >
            <h2 className="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-2 pt-5 flex items-center">
              <Icon className={`w-6 h-6 mr-3 text-[${PRIMARY_COLOR}]`} />
              {title}
            </h2>
            <p className="text-[#60748a] text-sm px-4 mb-3">{description}</p>
            <div className="p-4">
              <ContentComponent />
            </div>
          </section>
        ))}
      </div>
    </div>
  );
};

export default ServicesPage;