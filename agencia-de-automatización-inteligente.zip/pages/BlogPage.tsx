import React from 'react';
import { BlogPost } from '../types';
import { PLACEHOLDER_IMAGE_URL, PRIMARY_COLOR } from '../constants';
import { Link, useParams } from 'react-router-dom';
import Button from '../components/Button'; // For potential "Leer Más" or navigation

const blogPostsData: BlogPost[] = [
  {
    id: 'bp1',
    title: 'El Futuro de la Automatización: Tendencias Clave para 2025',
    summary: 'Exploramos las innovaciones en RPA, IA e hiperautomatización que transformarán los negocios el próximo año y cómo prepararse para ellas.',
    author: 'Dr. Innovación',
    date: '15 Julio, 2025', // Updated to 2025
    imageUrl: PLACEHOLDER_IMAGE_URL(400, 250, 'blog-future'),
    path: '/blog/futuro-automatizacion-2025',
    tags: ['Automatización', 'Tendencias 2025', 'IA', 'RPA']
  },
  {
    id: 'bp2',
    title: 'Integración de IA y Machine Learning en Procesos de Negocio',
    summary: 'Una guía práctica sobre cómo las empresas pueden integrar eficazmente la IA y el ML para optimizar operaciones y mejorar la toma de decisiones.',
    author: 'Ana Algoritmo',
    date: '10 Julio, 2025', // Updated to 2025
    imageUrl: PLACEHOLDER_IMAGE_URL(400, 250, 'blog-ai-ml'),
    path: '/blog/integracion-ia-ml',
    tags: ['IA', 'Machine Learning', 'Procesos de Negocio']
  },
  {
    id: 'bp3',
    title: 'Low-Code/No-Code: Democratizando la Innovación Tecnológica',
    summary: 'Descubra cómo las plataformas Low-Code y No-Code están empoderando a los usuarios no técnicos para crear soluciones y acelerar la digitalización.',
    author: 'Carlos Clic',
    date: '5 Julio, 2025', // Updated to 2025
    imageUrl: PLACEHOLDER_IMAGE_URL(400, 250, 'blog-lowcode'),
    path: '/blog/low-code-democratizacion',
    tags: ['Low-Code', 'No-Code', 'Innovación', 'Digitalización']
  },
  {
    id: 'bp4',
    title: 'Cumplimiento Normativo: Automatización del Registro de Jornada Laboral en España',
    summary: 'Todo lo que necesita saber sobre la obligatoriedad de automatizar el registro de jornada laboral en España desde 2025 y cómo nuestras soluciones pueden ayudarle a cumplir.',
    author: 'Laura Legal',
    date: '1 Julio, 2025', // Updated to 2025
    imageUrl: PLACEHOLDER_IMAGE_URL(400, 250, 'blog-normativa'),
    path: '/blog/cumplimiento-jornada-laboral',
    tags: ['Cumplimiento Normativo', 'España', 'Automatización', 'RRHH']
  },
   {
    id: 'bp5',
    title: 'SEO para Contenido: Cómo Google Clasifica su Información (EEAT)',
    summary: 'Entienda los principios de Experiencia, Pericia, Autoridad y Confianza (EEAT) y cómo optimizar su contenido para un mejor posicionamiento en Google.',
    author: 'Sergio Online',
    date: '25 Junio, 2025', // Updated to 2025
    imageUrl: PLACEHOLDER_IMAGE_URL(400, 250, 'blog-seo'),
    path: '/blog/seo-eeat-google',
    tags: ['SEO', 'Marketing Digital', 'Contenido', 'EEAT']
  },
   {
    id: 'bp6',
    title: 'Escalabilidad Inteligente: Cómo Crecer sin Perder Eficiencia',
    summary: 'Estrategias y tecnologías para asegurar que su infraestructura y procesos puedan escalar de manera eficiente a medida que su negocio crece.',
    author: 'Elena Expansión',
    date: '20 Junio, 2025', // Updated to 2025
    imageUrl: PLACEHOLDER_IMAGE_URL(400, 250, 'blog-scalability'),
    path: '/blog/escalabilidad-inteligente',
    tags: ['Escalabilidad', 'Eficiencia', 'Crecimiento']
  }
];

const BlogPage: React.FC = () => {
  return (
    <div className="flex flex-col">
      <div className={`bg-gradient-to-r from-red-500 via-pink-500 to-orange-500 text-white px-4 py-10 sm:px-10 sm:py-16 text-center`}>
        <h1 className="text-3xl sm:text-4xl font-black leading-tight tracking-tighter">Blog y Recursos de Conocimiento</h1>
        <p className="mt-3 text-base sm:text-lg text-red-100 max-w-3xl mx-auto">
          Manténgase al día con las últimas tendencias, guías y análisis sobre digitalización, automatización e inteligencia artificial.
        </p>
      </div>

      <section className="py-5">
        <h2 className="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">Artículos Recientes</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
          {blogPostsData.map(post => (
            <Link to={post.path} key={post.id} className="block group">
                <div className="h-full flex flex-col gap-0 rounded-lg border border-[#dbe0e6] bg-white overflow-hidden group-hover:shadow-xl transition-shadow duration-300">
                    {post.imageUrl && <img src={post.imageUrl} alt={post.title} className="w-full h-40 object-cover"/>}
                    <div className="p-4 flex flex-col flex-grow">
                        <h3 className={`text-[#111418] text-base font-bold leading-tight mb-1 group-hover:text-[${PRIMARY_COLOR}]`}>{post.title}</h3>
                        <p className="text-xs text-[#60748a] mb-2">{post.date} - por {post.author}</p>
                        <p className="text-sm text-[#60748a] leading-normal mb-3 flex-grow">{post.summary}</p>
                        {post.tags && post.tags.length > 0 && (
                        <div className="mt-auto pt-2">
                            {post.tags.map(tag => (
                            <span key={tag} className="inline-block bg-gray-100 rounded-full px-2 py-0.5 text-[10px] font-semibold text-[#60748a] mr-1 mb-1">
                                {tag}
                            </span>
                            ))}
                        </div>
                        )}
                    </div>
                </div>
            </Link>
          ))}
        </div>
        <div className="text-center mt-8 px-4">
            <p className="text-[#60748a] text-base leading-normal">Explore más artículos para profundizar su conocimiento o contáctenos para discutir sus necesidades.</p>
        </div>
      </section>
    </div>
  );
};

export default BlogPage;

export const BlogPostDetail: React.FC = () => {
    const { id } = useParams<{ id: string }>(); 
    const post = blogPostsData.find(p => p.path === `/blog/${id}`);

    if (!post) {
        return (
            <div className="flex flex-col items-center justify-center py-10 px-4 text-center">
                 <h1 className="text-3xl font-bold text-[#111418] mb-4">Artículo no Encontrado</h1>
                 <p className="text-[#60748a] mb-6">El artículo que busca no existe o ha sido movido.</p>
                 <Link to="/blog">
                    <Button variant="primary">Volver al Blog</Button>
                 </Link>
            </div>
        );
    }
    
    return (
        <div className="flex flex-col">
            <div className="bg-gradient-to-r from-gray-700 to-gray-800 text-white px-4 py-8 sm:px-10 sm:py-12 text-center">
                <h1 className="text-2xl sm:text-3xl font-black leading-tight tracking-tighter max-w-2xl mx-auto">{post.title}</h1>
                <p className="mt-2 text-sm text-gray-300">Por {post.author} - {post.date}</p>
            </div>
            <article className="p-4">
                {post.imageUrl && <img src={post.imageUrl} alt={post.title} className="w-full max-w-2xl mx-auto h-auto object-cover rounded-md mb-6 shadow-lg" />}
                <div className="prose prose-sm sm:prose-base lg:prose-lg max-w-2xl mx-auto text-[#111418]">
                    <p className="lead text-[#60748a]">{post.summary}</p>
                    <p>Este es un contenido de marcador de posición para el artículo detallado. En una aplicación real, aquí se representaría el contenido completo del blog, posiblemente desde un archivo Markdown o un CMS.</p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                    <h3 className="text-[#111418] font-bold mt-4">Subtítulo de Ejemplo</h3>
                    <p>Más contenido detallado aquí...</p>
                </div>
                {post.tags && post.tags.length > 0 && (
                  <div className="max-w-2xl mx-auto mt-6 pt-4 border-t border-[#dbe0e6]">
                    <h4 className="text-sm font-semibold text-[#111418] mb-2">Etiquetas:</h4>
                    {post.tags.map(tag => (
                      <span key={tag} className="inline-block bg-gray-100 rounded-full px-2 py-0.5 text-xs font-semibold text-[#60748a] mr-2 mb-2">
                        {tag}
                      </span>
                    ))}
                  </div>
                )}
                 <div className="max-w-2xl mx-auto mt-8">
                    <Link to="/blog" className={`text-[${PRIMARY_COLOR}] hover:text-red-700 font-semibold text-sm`}>&larr; Volver al Blog</Link>
                </div>
            </article>
        </div>
    );
};