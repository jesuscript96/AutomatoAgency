import React from 'react';
import ContactForm from '../components/ContactForm';
import { PLACEHOLDER_IMAGE_URL, PRIMARY_COLOR } from '../constants';

const ContactPage: React.FC = () => {
  return (
    <div className="flex flex-col">
      <div className={`bg-gradient-to-r from-red-500 to-orange-500 text-white px-4 py-10 sm:px-10 sm:py-16 text-center`}>
        <h1 className="text-3xl sm:text-4xl font-black leading-tight tracking-tighter">Contacte con Nosotros</h1>
        <p className="mt-3 text-base sm:text-lg text-red-100 max-w-3xl mx-auto">
          Estamos listos para ayudarle a transformar su negocio. Solicite una demostración gratuita o una consulta personalizada.
        </p>
      </div>

      <section className="py-5">
        <h2 className="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">Envíenos un Mensaje</h2>
        <div className="p-4">
          <ContactForm />
        </div>
      </section>

      <section className="py-5 bg-slate-50">
        <h2 className="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">Información de Contacto</h2>
        <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="rounded-lg border border-[#dbe0e6] bg-white p-4">
                <h3 className="text-base font-bold text-[#111418] mb-1">Dirección</h3>
                <p className="text-sm text-[#60748a] leading-normal">Alfonso Reyes 58, La Condesa,<br/>CDMX, México</p>
            </div>
            <div className="rounded-lg border border-[#dbe0e6] bg-white p-4">
                <h3 className="text-base font-bold text-[#111418] mb-1">Teléfono (WhatsApp)</h3>
                <p className="text-sm text-[#60748a] leading-normal"><a href="https://wa.me/34600412492" target="_blank" rel="noopener noreferrer" className={`hover:text-[${PRIMARY_COLOR}]`}>+34 600 412 492</a></p>
            </div>
            <div className="rounded-lg border border-[#dbe0e6] bg-white p-4">
                <h3 className="text-base font-bold text-[#111418] mb-1">Correo Electrónico</h3>
                <p className="text-sm text-[#60748a] leading-normal"><a href="mailto:jvalenzuela.chulia@gmail.com" className={`hover:text-[${PRIMARY_COLOR}]`}>jvalenzuela.chulia@gmail.com</a></p>
            </div>
            <div className="rounded-lg border border-[#dbe0e6] bg-white p-4">
                <h3 className="text-base font-bold text-[#111418] mb-1">Horario de Atención</h3>
                <p className="text-sm text-[#60748a] leading-normal">Lunes a Viernes: 9:00 - 18:00 (CDMX)</p>
            </div>
        </div>
        <div className="p-4 mt-2">
              <img 
                src={PLACEHOLDER_IMAGE_URL(600, 300, 'mapa-ubicacion-cdmx')} 
                alt="Ubicación en el mapa" 
                className="w-full h-auto rounded-md object-cover border border-[#dbe0e6]" 
              />
              <p className="text-xs text-[#60748a] mt-1 text-center">Simulación de mapa de nuestra ubicación en CDMX.</p>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;