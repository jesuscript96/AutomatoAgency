import React from 'react';
import FaqItem from '../components/FaqItem';
import { FaqItem as FaqItemType } from '../types';
import { PRIMARY_COLOR } from '../constants';

const faqData: FaqItemType[] = [
  {
    id: 'faq1',
    question: '¿Qué es la Automatización Robótica de Procesos (RPA)?',
    answer: 'La RPA es una tecnología que permite configurar software (o "robots") para emular e integrar las acciones de un ser humano interactuando con sistemas digitales para ejecutar un proceso de negocio. Los robots RPA utilizan la interfaz de usuario para capturar datos y manipular aplicaciones existentes del mismo modo que los humanos.'
  },
  {
    id: 'faq2',
    question: '¿Cómo puede la Inteligencia Artificial (IA) beneficiar a mi empresa?',
    answer: 'La IA puede aportar múltiples beneficios, como mejorar la toma de decisiones mediante análisis predictivos, automatizar tareas complejas, personalizar la experiencia del cliente, optimizar procesos, crear contenido automáticamente y descubrir ideas valiosas a partir de grandes volúmenes de datos.'
  },
  {
    id: 'faq3',
    question: '¿Cuánto tiempo se tarda en implementar una solución de automatización?',
    answer: 'El tiempo de implementación varía según la complejidad del proceso a automatizar y la tecnología utilizada. Proyectos de RPA sencillos pueden implementarse en pocas semanas, mientras que soluciones más complejas que involucren IA pueden llevar varios meses. Realizamos un análisis detallado para ofrecer una estimación precisa.'
  },
  {
    id: 'faq4',
    question: '¿Qué tipo de retorno de la inversión (ROI) puedo esperar?',
    answer: 'El ROI de la automatización puede ser significativo y manifestarse de diversas formas: reducción de costos operativos, aumento de la productividad, disminución de errores, mejora de la satisfacción del cliente y del empleado, y mayor agilidad empresarial. Calculamos el ROI potencial para cada proyecto.'
  },
  {
    id: 'faq5',
    question: '¿Es necesario tener conocimientos técnicos para utilizar plataformas Low-Code/No-Code?',
    answer: 'No necesariamente. Estas plataformas están diseñadas para que usuarios con poca o ninguna experiencia en programación (desarrolladores ciudadanos) puedan crear aplicaciones y automatizaciones utilizando interfaces visuales e intuitivas. Nosotros ofrecemos la capacitación necesaria.'
  },
  {
    id: 'faq6',
    question: '¿Cómo garantizan la seguridad de los datos en los procesos automatizados?',
    answer: 'La seguridad es una prioridad. Implementamos medidas robustas como encriptación de datos, controles de acceso estrictos, pistas de auditoría, y seguimos las mejores prácticas de ciberseguridad. Además, nos aseguramos de cumplir con las regulaciones de protección de datos aplicables.'
  },
  {
    id: 'faq7',
    question: '¿Qué pasa si mis procesos de negocio cambian después de la implementación?',
    answer: 'Nuestras soluciones están diseñadas para ser flexibles y escalables. Ofrecemos soporte continuo y podemos adaptar las automatizaciones a los cambios en sus procesos de negocio para asegurar que sigan aportando valor.'
  }
];

const FaqPage: React.FC = () => {
  return (
    <div className="flex flex-col">
      <div className={`bg-gradient-to-r from-red-600 to-orange-500 text-white px-4 py-10 sm:px-10 sm:py-16 text-center`}>
        <h1 className="text-3xl sm:text-4xl font-black leading-tight tracking-tighter">Preguntas Frecuentes (FAQs)</h1>
        <p className="mt-3 text-base sm:text-lg text-red-100 max-w-3xl mx-auto">
          Encuentre respuestas a las dudas más comunes sobre nuestros servicios de automatización, digitalización y los beneficios que podemos aportar a su empresa.
        </p>
      </div>

      <section className="py-5">
        <h2 className="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">Respuestas a sus Dudas</h2>
        <div className="p-4">
          <dl className="space-y-3">
            {faqData.map(item => (
              <FaqItem key={item.id} question={item.question} answer={item.answer} />
            ))}
          </dl>
        </div>
      </section>
      
      <section className="px-4 py-10 sm:py-16 text-center bg-slate-50">
        <h2 className="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] mb-2">
          ¿Tiene más Preguntas?
        </h2>
        <p className="text-[#60748a] text-base leading-normal max-w-xl mx-auto mb-6">
          Si no encuentra la respuesta que busca, no dude en contactarnos. Nuestro equipo de expertos está listo para ayudarle.
        </p>
        <a href="/#/contacto?asunto=pregunta_adicional" 
           className={`inline-block px-5 py-3 bg-[${PRIMARY_COLOR}] text-white text-sm font-bold leading-normal tracking-tight rounded-lg hover:opacity-90 transition-opacity`}
           style={{ backgroundColor: PRIMARY_COLOR }} // Ensure inline style for direct hex
        >
          Contactar Ahora
        </a>
      </section>
    </div>
  );
};

export default FaqPage;