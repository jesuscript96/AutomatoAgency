import React from 'react';
import { CaseStudy, Testimonial } from '../types';
import { PLACEHOLDER_IMAGE_URL, DEMO_CTA_TEXT, PRIMARY_COLOR } from '../constants';
import { Link } from 'react-router-dom';
import Button from '../components/Button';


const caseStudiesData: CaseStudy[] = [
  {
    id: 'uc1',
    title: 'Optimización del Onboarding de Empleados en Multinacional de RRHH',
    // client: 'Recursos Humanos Globales S.A.', // Removed for privacy
    problem: 'El proceso de alta de nuevos empleados era manual, propenso a errores y consumía 5 días laborables.',
    solution: 'Implementación de una solución RPA integrada con IA para automatizar la recopilación de documentos, creación de accesos y notificaciones.',
    results: 'Reducción del ciclo de alta de empleados de 5 días a 24 horas. Mejora del 90% en la precisión de datos y aumento de la satisfacción del nuevo empleado.',
    imageUrl: PLACEHOLDER_IMAGE_URL(400, 250, 'case-hr'),
    tags: ['RPA', 'IA', 'Recursos Humanos', 'Eficiencia']
  },
  {
    id: 'uc2',
    title: 'Ahorro Anual de $300,000 en Marketing Automation para E-commerce',
    // client: 'Marketing Dinámico Inc.', // Removed for privacy
    problem: 'Gestión manual de campañas de email marketing y nutrición de leads, resultando en altos costos y baja conversión.',
    solution: 'Desarrollo e implementación de flujos de trabajo automatizados para la segmentación de audiencias, envío de emails personalizados y seguimiento de leads, utilizando IA para optimizar el contenido y el timing.',
    results: 'Ahorro anual promedio de $300,000 USD. Incremento del 35% en la tasa de conversión de leads y mejora del 50% en la eficiencia del equipo de marketing.',
    imageUrl: PLACEHOLDER_IMAGE_URL(400, 250, 'case-marketing'),
    tags: ['Marketing Automation', 'IA', 'Ahorro de Costos', 'E-commerce']
  },
  {
    id: 'uc3',
    title: 'Transformación Digital en Sector Bancario: Automatización de Conciliaciones',
    // client: 'Banco Innovador Crediticio', // Removed for privacy
    problem: 'Procesos de conciliación bancaria manuales, lentos y con alto riesgo de errores, afectando el cierre mensual.',
    solution: 'Implementación de bots RPA para automatizar la extracción de datos de múltiples fuentes, realizar comparaciones y generar informes de conciliación, con alertas para excepciones.',
    results: 'Reducción del tiempo de conciliación en un 80%. Eliminación de errores manuales y cumplimiento normativo mejorado. Liberación de 5 FTEs para análisis financiero estratégico.',
    imageUrl: PLACEHOLDER_IMAGE_URL(400, 250, 'case-banca'),
    tags: ['RPA', 'Finanzas', 'Banca', 'Cumplimiento']
  },
];

const testimonialsData: Testimonial[] = [
    { id: 't1', quote: 'La solución de automatización transformó nuestra logística. Ahora somos más rápidos y precisos que nunca.', author: 'Javier Solís', company: 'Logística Eficaz Ltda.', logoUrl: PLACEHOLDER_IMAGE_URL(120,50,'logo-logistica') },
    { id: 't2', quote: 'Gracias a su experiencia en IA, hemos optimizado nuestras previsiones de demanda, reduciendo el desperdicio en un 20%.', author: 'Laura Méndez', company: 'Retail Conectado', logoUrl: PLACEHOLDER_IMAGE_URL(120,50,'logo-retail') },
    { id: 't3', quote: 'El soporte y la personalización que recibimos fueron excepcionales. Recomiendo encarecidamente sus servicios.', author: 'Miguel Ángel Torres', company: 'Manufacturas Modernas', logoUrl: PLACEHOLDER_IMAGE_URL(120,50,'logo-manufactura') },
];


const UseCasesPage: React.FC = () => {
  return (
    <div className="flex flex-col">
       <div className={`bg-gradient-to-r from-red-500 to-orange-500 text-white px-4 py-10 sm:px-10 sm:py-16 text-center`}>
        <h1 className="text-3xl sm:text-4xl font-black leading-tight tracking-tighter">Casos de Éxito Inspiradores</h1>
        <p className="mt-3 text-base sm:text-lg text-red-100 max-w-3xl mx-auto">
          Descubra cómo hemos ayudado a empresas como la suya a alcanzar resultados extraordinarios mediante la automatización y la digitalización.
        </p>
      </div>

      <section className="py-5">
        <h2 className="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">Nuestros Proyectos Destacados</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4">
          {caseStudiesData.map(cs => (
            <div key={cs.id} className="flex flex-col gap-3 rounded-lg border border-[#dbe0e6] bg-white overflow-hidden">
              {cs.imageUrl && <img src={cs.imageUrl} alt={cs.title} className="w-full h-48 object-cover"/>}
              <div className="p-4 flex flex-col flex-grow">
                <h3 className="text-[#111418] text-base font-bold leading-tight mb-1">{cs.title}</h3>
                <p className={`text-xs text-[${PRIMARY_COLOR}] font-medium mb-2`}>{'Cliente Confidencial'}</p>
                
                <h4 className="text-xs font-semibold text-[#111418] mt-2">Problema:</h4>
                <p className="text-xs text-[#60748a] mb-1 leading-normal">{cs.problem}</p>
                <h4 className="text-xs font-semibold text-[#111418] mt-1">Solución:</h4>
                <p className="text-xs text-[#60748a] mb-1 leading-normal">{cs.solution}</p>
                <h4 className="text-xs font-semibold text-[#111418] mt-1">Resultados:</h4>
                <p className="text-xs text-green-600 font-medium leading-normal">{cs.results}</p>
                
                {cs.tags && cs.tags.length > 0 && (
                  <div className="mt-auto pt-3">
                    {cs.tags.map(tag => (
                      <span key={tag} className="inline-block bg-gray-100 rounded-full px-2 py-0.5 text-[10px] font-semibold text-[#60748a] mr-1 mb-1">
                        {tag}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="py-10 bg-slate-50">
        <h2 className="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5 text-center">Testimonios de Clientes Satisfechos</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4">
          {testimonialsData.map(testimonial => (
             <div key={testimonial.id} className="flex flex-col gap-3 rounded-lg border border-[#dbe0e6] bg-white p-4 items-center text-center">
              {testimonial.logoUrl && <img src={testimonial.logoUrl} alt={testimonial.company} className="h-10 w-auto mb-2 object-contain"/>}
              <blockquote className="text-sm text-[#60748a] italic leading-normal flex-grow">"{testimonial.quote}"</blockquote>
              <div className="mt-2">
                <p className="text-sm font-bold text-[#111418]">{testimonial.author}</p>
                <p className={`text-xs text-[${PRIMARY_COLOR}]`}>{testimonial.company}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="px-4 py-10 sm:py-16 text-center">
        <h2 className="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] mb-2">
          ¿Listo para ser Nuestro Próximo Caso de Éxito?
        </h2>
        <p className="text-[#60748a] text-base leading-normal max-w-xl mx-auto mb-6">
          Permítanos ayudarle a alcanzar sus objetivos de negocio con nuestras soluciones personalizadas de automatización y digitalización.
        </p>
        <Link to="/contacto?asunto=consulta">
          <Button variant="primary" size="lg">
            {DEMO_CTA_TEXT}
          </Button>
        </Link>
      </section>
    </div>
  );
};

export default UseCasesPage;