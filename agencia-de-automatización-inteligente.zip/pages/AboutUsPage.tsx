import React from 'react';
import { TeamMember } from '../types';
import { PLACEHOLDER_IMAGE_URL, DEMO_CTA_TEXT, PRIMARY_COLOR } from '../constants';
import AcademicCapIcon from '../components/icons/AcademicCapIcon';
import UserGroupIcon from '../components/icons/UserGroupIcon';
import SparklesIcon from '../components/icons/SparklesIcon'; 
import { Link } from 'react-router-dom';
import Button from '../components/Button';


const teamMembersData: TeamMember[] = [
  { id: 'tm1', name: 'Elena Rico', role: 'CEO y Experta en Estrategia Digital', imageUrl: PLACEHOLDER_IMAGE_URL(150, 150, 'elena'), bio: 'Con más de 15 años de experiencia liderando proyectos de transformación digital, Elena es una visionaria en la aplicación de IA y RPA para el crecimiento empresarial.' },
  { id: 'tm2', name: 'Marcos Herrera', role: 'CTO y Arquitecto de Soluciones IA', imageUrl: PLACEHOLDER_IMAGE_URL(150, 150, 'marcos'), bio: 'Marcos es un innovador en IA generativa y Minería de Procesos, apasionado por construir soluciones tecnológicas robustas y escalables.' },
  { id: 'tm3', name: 'Sofía Castillo', role: 'Directora de Operaciones y RPA', imageUrl: PLACEHOLDER_IMAGE_URL(150, 150, 'sofia'), bio: 'Sofía se especializa en la optimización de procesos mediante RPA y Low-Code, asegurando implementaciones eficientes y de alto impacto.' },
  { id: 'tm4', name: 'Javier Morales', role: 'Líder en Analítica de Datos', imageUrl: PLACEHOLDER_IMAGE_URL(150, 150, 'javier'), bio: 'Javier convierte datos complejos en ideas accionables, ayudando a las empresas a tomar decisiones más inteligentes y predictivas.' },
];

const AboutUsPage: React.FC = () => {
  return (
    <div className="flex flex-col">
      <div className={`bg-gradient-to-r from-red-500 to-orange-500 text-white px-4 py-10 sm:px-10 sm:py-16 text-center`}>
        <h1 className="text-3xl sm:text-4xl font-black leading-tight tracking-tighter">Sobre Nosotros: Impulsores de su Evolución Digital</h1>
        <p className="mt-3 text-base sm:text-lg text-red-100 max-w-3xl mx-auto">
          Conozca al equipo y la filosofía detrás de su socio estratégico en automatización y digitalización.
        </p>
      </div>

      <section id="filosofia" className="py-5">
        <h2 className="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">Nuestra Filosofía: Colaboración Inteligente</h2>
        <div className="p-4 space-y-4">
          <div className="flex flex-col gap-3 rounded-lg border border-[#dbe0e6] bg-white p-4 sm:flex-row sm:items-start sm:gap-4">
            <AcademicCapIcon className={`w-10 h-10 text-[${PRIMARY_COLOR}] flex-shrink-0 sm:mt-1`}/>
            <div>
                <h3 className="text-[#111418] text-base font-bold leading-tight mb-1">IA como Copiloto: Empoderando Personas</h3>
                <p className="text-sm text-[#60748a] leading-normal">Creemos firmemente en el poder de la colaboración entre humanos e inteligencia artificial. Vemos la IA no como un reemplazo, sino como un "copiloto" inteligente que aumenta las capacidades humanas, libera el potencial creativo y permite a los empleados centrarse en tareas de mayor valor estratégico y satisfacción personal.</p>
            </div>
          </div>
          <div className="flex flex-col gap-3 rounded-lg border border-[#dbe0e6] bg-white p-4 sm:flex-row sm:items-start sm:gap-4">
            <UserGroupIcon className={`w-10 h-10 text-[${PRIMARY_COLOR}] flex-shrink-0 sm:mt-1`}/>
            <div>
                <h3 className="text-[#111418] text-base font-bold leading-tight mb-1">Adaptabilidad y Crecimiento Sostenible</h3>
                <p className="text-sm text-[#60748a] leading-normal">El mercado evoluciona constantemente, y su negocio también debe hacerlo. Diseñamos soluciones flexibles y escalables que se adaptan a sus necesidades cambiantes, asegurando un crecimiento sostenible y una ventaja competitiva a largo plazo. Fomentamos una cultura de aprendizaje y mejora continua.</p>
            </div>
          </div>
        </div>
      </section>

      <section id="equipo" className="py-10 bg-slate-50">
        <h2 className="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-1 pt-5 text-center">Conozca a Nuestros Expertos</h2>
        <p className="text-center text-sm text-[#60748a] leading-normal mb-6 max-w-2xl mx-auto px-4">
          Nuestro equipo está formado por profesionales apasionados y con un profundo conocimiento en RPA, Minería de Procesos, IA generativa, analítica de datos y estrategias de digitalización.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 p-4">
          {teamMembersData.map(member => (
            <div key={member.id} className="flex flex-col items-center text-center gap-2 rounded-lg border border-[#dbe0e6] bg-white p-4">
              <img src={member.imageUrl} alt={member.name} className={`w-24 h-24 rounded-full object-cover border-2 border-[${PRIMARY_COLOR}]`} />
              <h3 className="text-[#111418] text-base font-bold leading-tight">{member.name}</h3>
              <p className={`text-xs text-[${PRIMARY_COLOR}] font-medium`}>{member.role}</p>
              <p className="text-xs text-[#60748a] leading-normal">{member.bio}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="diferenciacion" className="py-5">
         <h2 className="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">Nuestra Diferenciación: Su Éxito es Nuestro Compromiso</h2>
         <div className="p-4 space-y-4">
            <div className="flex flex-col gap-3 rounded-lg border border-[#dbe0e6] bg-white p-4 sm:flex-row sm:items-start sm:gap-4">
                <SparklesIcon className={`w-10 h-10 text-[${PRIMARY_COLOR}] flex-shrink-0 sm:mt-1`}/>
                <div>
                    <h3 className="text-[#111418] text-base font-bold leading-tight mb-1">Superando la Resistencia al Cambio</h3>
                    <p className="text-sm text-[#60748a] leading-normal">Entendemos que la adopción de nuevas tecnologías puede generar incertidumbre. Por ello, trabajamos de cerca con sus equipos, fomentando una cultura de cambio positivo, proporcionando capacitación integral y asegurando una integración fluida y participativa de las nuevas herramientas y procesos.</p>
                </div>
            </div>
             <div className="flex flex-col gap-3 rounded-lg border border-[#dbe0e6] bg-white p-4 sm:flex-row sm:items-start sm:gap-4">
                <AcademicCapIcon className={`w-10 h-10 text-[${PRIMARY_COLOR}] flex-shrink-0 sm:mt-1`}/>
                <div>
                    <h3 className="text-[#111418] text-base font-bold leading-tight mb-1">Inversión en Capacitación Continua</h3>
                    <p className="text-sm text-[#60748a] leading-normal">No solo implementamos soluciones, sino que también empoderamos a su personal. Invertimos en programas de capacitación continua para que sus empleados dominen las nuevas tecnologías y se conviertan en agentes activos de la transformación digital de su empresa.</p>
                </div>
            </div>
             <div className="flex flex-col gap-3 rounded-lg border border-[#dbe0e6] bg-white p-4 sm:flex-row sm:items-start sm:gap-4">
                <UserGroupIcon className={`w-10 h-10 text-[${PRIMARY_COLOR}] flex-shrink-0 sm:mt-1`}/>
                <div>
                    <h3 className="text-[#111418] text-base font-bold leading-tight mb-1">Integración Fluida y Soporte Experto</h3>
                    <p className="text-sm text-[#60748a] leading-normal">Garantizamos una integración sin contratiempos de las nuevas soluciones con sus sistemas existentes. Ofrecemos un soporte técnico experto y proactivo para resolver cualquier incidencia y asegurar el óptimo rendimiento de las herramientas implementadas.</p>
                </div>
            </div>
         </div>
      </section>
      <section className="px-4 py-10 sm:py-16 text-center">
        <h2 className="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] mb-2">
          ¿Interesado en Unirse a Nuestro Equipo o Colaborar?
        </h2>
        <p className="text-[#60748a] text-base leading-normal max-w-xl mx-auto mb-6">
          Siempre estamos buscando talento apasionado y oportunidades de colaboración innovadoras. Contáctenos para explorar posibilidades.
        </p>
        <Link to="/contacto?asunto=colaboracion">
          <Button variant="primary" size="lg">
            Contactar
          </Button>
        </Link>
      </section>
    </div>
  );
};

export default AboutUsPage;