import React from 'react';
import { Link } from 'react-router-dom';
import Button from '../components/Button';

const NotFoundPage: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center text-center py-10 px-4 min-h-[calc(100vh-200px)]"> {/* Adjust min-h if needed */}
      <img src="https://picsum.photos/seed/404errorpage/300/200" alt="Ilustración de error 404" className="mb-8 rounded-lg shadow-md"/>
      <h1 className="text-3xl sm:text-4xl font-black text-[#111418] leading-tight tracking-tighter mb-3">
        Error 404: Página No Encontrada
      </h1>
      <p className="text-base text-[#60748a] leading-normal max-w-md mx-auto mb-8">
        ¡Vaya! Parece que la página que está buscando no existe o ha sido movida.
      </p>
      <Link to="/">
        <Button variant="primary" size="lg">
          Volver a la Página de Inicio
        </Button>
      </Link>
    </div>
  );
};

export default NotFoundPage;