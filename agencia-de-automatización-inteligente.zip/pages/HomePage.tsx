import React from 'react';
import Hero from '../components/Hero';
import Button from '../components/Button';
import { APP_NAME, DEMO_CTA_TEXT, PRIMARY_COLOR } from '../constants';
import { Link } from 'react-router-dom';

// Icons from example, ensuring color #111418 as base for some, red for others if accent
const ClockIcon: React.FC<{className?: string}> = ({className = "text-[#111418]"}) => <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256" className={className}><path d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Zm64-88a8,8,0,0,1-8,8H128a8,8,0,0,1-8-8V72a8,8,0,0,1,16,0v48h48A8,8,0,0,1,192,128Z"></path></svg>;
const DollarIconPage: React.FC<{className?: string}> = ({className = "text-[#111418]"}) => <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256" className={className}><path d="M152,120H136V56h8a32,32,0,0,1,32,32,8,8,0,0,0,16,0,48.05,48.05,0,0,0-48-48h-8V24a8,8,0,0,0-16,0V40h-8a48,48,0,0,0,0,96h8v64H104a32,32,0,0,1-32-32,8,8,0,0,0-16,0,48.05,48.05,0,0,0,48,48h16v16a8,8,0,0,0,16,0V216h16a48,48,0,0,0,0-96Zm-40,0a32,32,0,0,1,0-64h8v64Zm40,80H136V136h16a32,32,0,0,1,0,64Z"></path></svg>;
const UsersThreeIconPage: React.FC<{className?: string}> = ({className = "text-[#111418]"}) => <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256" className={className}><path d="M244.8,150.4a8,8,0,0,1-11.2-1.6A51.6,51.6,0,0,0,192,128a8,8,0,0,1-7.37-4.89,8,8,0,0,1,0-6.22A8,8,0,0,1,192,112a24,24,0,1,0-23.24-30,8,8,0,1,1-15.5-4A40,40,0,1,1,219,117.51a67.94,67.94,0,0,1,27.43,21.68A8,8,0,0,1,244.8,150.4ZM190.92,212a8,8,0,1,1-13.84,8,57,57,0,0,0-98.16,0,8,8,0,1,1-13.84-8,72.06,72.06,0,0,1,33.74-29.92,48,48,0,1,1,58.36,0A72.06,72.06,0,0,1,190.92,212ZM128,176a32,32,0,1,0-32-32A32,32,0,0,0,128,176ZM72,120a8,8,0,0,0-8-8A24,24,0,1,1,87.24,82a8,8,0,1,0,15.5-4A40,40,0,1,0,37,117.51,67.94,67.94,0,0,0,9.6,139.19a8,8,0,1,0,12.8,9.61A51.6,51.6,0,0,1,64,128,8,8,0,0,0,72,120Z"></path></svg>;

const RobotIcon: React.FC<{className?: string}> = ({className = `text-[${PRIMARY_COLOR}]`}) => <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256" className={className}><path d="M200,48H136V16a8,8,0,0,0-16,0V48H56A32,32,0,0,0,24,80V192a32,32,0,0,0,32,32H200a32,32,0,0,0,32-32V80A32,32,0,0,0,200,48Zm16,144a16,16,0,0,1-16,16H56a16,16,0,0,1-16-16V80A16,16,0,0,1,56,64H200a16,16,0,0,1,16,16Zm-52-56H92a28,28,0,0,0,0,56h72a28,28,0,0,0,0-56Zm-28,16v24H120V152ZM80,164a12,12,0,0,1,12-12h12v24H92A12,12,0,0,1,80,164Zm84,12H152V152h12a12,12,0,0,1,0,24ZM72,108a12,12,0,1,1,12,12A12,12,0,0,1,72,108Zm88,0a12,12,0,1,1,12,12A12,12,0,0,1,160,108Z"></path></svg>;
const FileIcon: React.FC<{className?: string}> = ({className = `text-[${PRIMARY_COLOR}]`}) => <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256" className={className}><path d="M213.66,82.34l-56-56A8,8,0,0,0,152,24H56A16,16,0,0,0,40,40V216a16,16,0,0,0,16,16H200a16,16,0,0,0,16-16V88A8,8,0,0,0,213.66,82.34ZM160,51.31,188.69,80H160ZM200,216H56V40h88V88a8,8,0,0,0,8,8h48V216Z"></path></svg>;
const ChartLineIcon: React.FC<{className?: string}> = ({className = `text-[${PRIMARY_COLOR}]`}) => <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256" className={className}><path d="M232,208a8,8,0,0,1-8,8H32a8,8,0,0,1-8-8V48a8,8,0,0,1,16,0v94.37L90.73,98a8,8,0,0,1,10.07-.38l58.81,44.11L218.73,90a8,8,0,1,1,10.54,12l-64,56a8,8,0,0,1-10.07.38L96.39,114.29,40,163.63V200H224A8,8,0,0,1,232,208Z"></path></svg>;
const UsersIcon: React.FC<{className?: string}> = ({className = `text-[${PRIMARY_COLOR}]`}) => <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256" className={className}><path d="M117.25,157.92a60,60,0,1,0-66.5,0A95.83,95.83,0,0,0,3.53,195.63a8,8,0,1,0,13.4,8.74,80,80,0,0,1,134.14,0,8,8,0,0,0,13.4-8.74A95.83,95.83,0,0,0,117.25,157.92ZM40,108a44,44,0,1,1,44,44A44.05,44.05,0,0,1,40,108Zm210.14,98.7a8,8,0,0,1-11.07-2.33A79.83,79.83,0,0,0,172,168a8,8,0,0,1,0-16,44,44,0,1,0-16.34-84.87,8,8,0,1,1-5.94-14.85,60,60,0,0,1,55.53,105.64,95.83,95.83,0,0,1,47.22,37.71A8,8,0,0,1,250.14,206.7Z"></path></svg>;
const ShieldCheckIconComponent: React.FC<{className?: string}> = ({className = `text-[${PRIMARY_COLOR}]`}) => <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256" className={className}><path d="M208,40H48A16,16,0,0,0,32,56v58.78c0,89.61,75.82,119.34,91,124.39a15.53,15.53,0,0,0,10,0c15.2-5.05,91-34.78,91-124.39V56A16,16,0,0,0,208,40Zm0,74.79c0,78.42-66.35,104.62-80,109.18-13.53-4.51-80-30.69-80-109.18V56H208ZM82.34,141.66a8,8,0,0,1,11.32-11.32L112,148.68l50.34-50.34a8,8,0,0,1,11.32,11.32l-56,56a8,8,0,0,1-11.32,0Z"></path></svg>;


const problemsData = [
  { id: 'p1', text: 'Flujos de Trabajo Ineficientes', icon: <ClockIcon /> },
  { id: 'p2', text: 'Altos Costos Operativos', icon: <DollarIconPage /> },
  { id: 'p3', text: 'Falta de Agilidad Digital', icon: <UsersThreeIconPage /> },
];

const solutionsData = [
  { id: 's1', title: 'Automatización Inteligente', description: 'Automatice tareas y flujos de trabajo repetitivos utilizando IA y automatización robótica de procesos (RPA).', icon: <RobotIcon /> },
  { id: 's2', title: 'Digitalización de Documentos', description: 'Digitalice documentos en papel y optimice los procesos de gestión documental.', icon: <FileIcon /> },
  { id: 's3', title: 'Optimización de Procesos', description: 'Analice y optimice sus procesos de negocio para obtener la máxima eficiencia y rendimiento.', icon: <ChartLineIcon /> },
];

const successStoriesData = [
  { id: 'ss1', title: 'Operaciones Optimizadas para una Empresa Financiera', description: 'Una empresa financiera automatizó el procesamiento de facturas, reduciendo el tiempo de procesamiento en un 60% y ahorrando miles de dólares anualmente.', imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB7dFxVtU4Xh0nDACDDdlvQymj93_UpQYPe4qhmyJW5Gxv3nPUjo6XNDPdEgNIWSLU4wzgRRkfRgENJAh8LNcjabUFkmcXyCP2DUvF4n_j8dE3VYKquWklnhkUow_bRCV-cri8yxWVNr3DPT74JcsogzBAmN_vca7COHqshAJjLJjQP7QmSn8gXhFrdGNd6LcUEliLOvFXWVvsdPudA85GjTm1AMXZa93VF1gspU8a_ryNv8YqlT4BBCoiFLA4vlSltHhyl2TmhKgs' },
  { id: 'ss2', title: 'Mejora del Servicio al Cliente para un Minorista', description: 'Un minorista digitalizó su sistema de feedback de clientes, lo que llevó a una mejora del 25% en las puntuaciones de satisfacción del cliente.', imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAbT7rag899UQLpIeYqrbms_zkcyebG25T3egvyMS-xCO9nZVNgYmxdOfEjZ8MM0lJnZ2lDgBQKfEZ3_oOQmjJuluRmL8eoFLmYkA8BfXA2aXq4Sps1oqmTPkuhqjWGH5RIvnQzahFhTbfkCc9MZRaeceTGPjzwnau3vJ-3_MQVom0HdR35n65lWkHNm_hA92rMc9t_uf2Lypneg_OmNY0UpKCHyqLRkDblgbxV1AEhoY65OPG-Ik64af1NdPt45tmoWZznO7fMveM' },
  { id: 'ss3', title: 'Eficiencia Mejorada para un Proveedor de Salud', description: 'Un proveedor de atención médica optimizó su proceso de programación de pacientes, lo que resultó en una reducción del 15% en los tiempos de espera.', imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCvieaojIC_cLfEy0ZXS2F1ARb3zaqHVyTbVhwQ2XIgPnszXtICHhrzyYSFH3J1olo-xtLUvJuQqrvRroUF64gAgjHlXqFX9o8AzoF18aznk0j4whJL00mjerPDSsurGJM9HjBigN_nKn7hH7xFvGvkZZmvbjs6r_tl-7_0gmRvVUMAVvwclfMou28q5RbYTolMR5DlQLCrLEj556NVBrl2-S5DjggU9zQ_Munjry8J6yec6Q3jsSs5SHBfq8nJuYrChZfZOYq5YiU' },
];

const whyChooseUsData = [
    { id: 'wc1', title: 'Equipo Experto', description: 'Nuestro equipo de expertos en automatización y digitalización está dedicado a ofrecer resultados excepcionales.', icon: <UsersIcon /> },
    { id: 'wc2', title: 'Resultados Comprobados', description: 'Tenemos un historial de éxito ayudando a las empresas a alcanzar sus objetivos mediante la automatización y la digitalización.', icon: <ShieldCheckIconComponent /> },
    { id: 'wc3', title: 'Implementación Rápida', description: 'Trabajamos eficientemente para implementar soluciones rápidamente y minimizar la interrupción de su negocio.', icon: <ClockIcon className={`text-[${PRIMARY_COLOR}]`} /> },
];


const HomePage: React.FC = () => {
  return (
    <div className="flex flex-col gap-0">
      <Hero
        title="Transforme su Negocio con Automatización Inteligente y Digitalización"
        subtitle={`Desbloquee nuevos niveles de eficiencia, ahorro de costos e innovación automatizando sus flujos de trabajo y digitalizando sus procesos con ${APP_NAME}.`}
      />

      <section className="py-5">
        <h2 className="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">Abordando los Desafíos de su Negocio</h2>
        <div className="grid grid-cols-[repeat(auto-fit,minmax(200px,1fr))] gap-3 p-4 md:grid-cols-[repeat(auto-fit,minmax(158px,1fr))]">
          {problemsData.map(problem => (
            <div key={problem.id} className="flex flex-1 gap-3 rounded-lg border border-[#dbe0e6] bg-white p-4 items-center">
              <div className="w-6 h-6">{problem.icon}</div>
              <h3 className="text-[#111418] text-base font-bold leading-tight">{problem.text}</h3>
            </div>
          ))}
        </div>
      </section>

      <section className="px-4 py-10">
        <div className="flex flex-col gap-4 mb-8">
          <h1 className="text-[#111418] text-[32px] font-bold leading-tight tracking-tighter sm:text-4xl sm:font-black max-w-[720px]">
            Potenciando su Negocio con Soluciones de Vanguardia
          </h1>
          <p className="text-[#111418] text-base font-normal leading-normal max-w-[720px]">
            Nuestro conjunto integral de soluciones está diseñado para abordar sus necesidades comerciales específicas e impulsar resultados tangibles.
          </p>
        </div>
        <div className="grid grid-cols-[repeat(auto-fit,minmax(200px,1fr))] gap-3 md:grid-cols-[repeat(auto-fit,minmax(158px,1fr))]">
          {solutionsData.map(solution => (
            <div key={solution.id} className="flex flex-1 gap-3 rounded-lg border border-[#dbe0e6] bg-white p-4 flex-col">
              <div className="w-6 h-6 mb-2">{solution.icon}</div>
              <div className="flex flex-col gap-1">
                <h2 className="text-[#111418] text-base font-bold leading-tight">{solution.title}</h2>
                <p className="text-[#60748a] text-sm font-normal leading-normal">{solution.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="py-5">
        <h2 className="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">Casos de Éxito</h2>
        <div className="flex overflow-x-auto [-ms-scrollbar-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          <div className="flex items-stretch p-4 gap-3">
            {successStoriesData.map(story => (
              <div key={story.id} className="flex h-full flex-1 flex-col gap-4 rounded-lg min-w-[240px] sm:min-w-60">
                <div
                  className="w-full bg-center bg-no-repeat aspect-square bg-cover rounded-lg"
                  style={{ backgroundImage: `url("${story.imageUrl}")` }}
                ></div>
                <div>
                  <p className="text-[#111418] text-base font-medium leading-normal">{story.title}</p>
                  <p className="text-[#60748a] text-sm font-normal leading-normal">{story.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      <section className="px-4 py-10">
        <div className="flex flex-col gap-4 mb-8">
          <h1 className="text-[#111418] text-[32px] font-bold leading-tight tracking-tighter sm:text-4xl sm:font-black max-w-[720px]">
            Su Socio de Confianza para la Transformación Digital
          </h1>
          <p className="text-[#111418] text-base font-normal leading-normal max-w-[720px]">
            Estamos comprometidos a proporcionar soluciones innovadoras y un servicio excepcional para ayudar a su negocio a prosperar en la era digital.
          </p>
        </div>
        <div className="grid grid-cols-[repeat(auto-fit,minmax(200px,1fr))] gap-3 md:grid-cols-[repeat(auto-fit,minmax(158px,1fr))]">
          {whyChooseUsData.map(item => (
            <div key={item.id} className="flex flex-1 gap-3 rounded-lg border border-[#dbe0e6] bg-white p-4 flex-col">
              <div className="w-6 h-6 mb-2">{item.icon}</div>
              <div className="flex flex-col gap-1">
                <h2 className="text-[#111418] text-base font-bold leading-tight">{item.title}</h2>
                <p className="text-[#60748a] text-sm font-normal leading-normal">{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="px-4 py-10 sm:py-20">
        <div className="flex flex-col justify-end gap-6 sm:gap-8 items-center text-center">
          <div className="flex flex-col gap-2">
            <h1 className="text-[#111418] text-[32px] font-bold leading-tight tracking-tighter sm:text-4xl sm:font-black max-w-[720px] mx-auto">
              ¿Listo para Transformar su Negocio?
            </h1>
            <p className="text-[#111418] text-base font-normal leading-normal max-w-[720px] mx-auto">
              Contáctenos hoy para una consulta gratuita y descubra cómo la automatización y la digitalización pueden beneficiar a su organización.
            </p>
          </div>
          <Link to="/contacto?asunto=demo">
            <Button variant="primary" size="lg" className="sm:text-base">
                {DEMO_CTA_TEXT}
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;